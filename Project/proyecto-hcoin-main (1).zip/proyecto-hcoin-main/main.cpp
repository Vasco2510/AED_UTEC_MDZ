#include "menu.h"
using namespace std;

int main() {
    Blockchain *heiderCoin = new Blockchain();
    Menu(heiderCoin);
    return 0;
}
