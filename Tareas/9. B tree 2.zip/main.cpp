
#include <iostream>
#include <vector>
#include <ctime>
#include "btree.h"
using namespace std;

int main(){
    srand(time(nullptr));
    BTree<int>* btree = new BTree<int>(4);

    vector<int> elements;
    for(int i=0;i<55;i++){
        int k = 1 + rand() % 100;
        elements.push_back(k);
        btree->insert(k);
    }

    btree->display_pretty();

    for(int i=0;i<3;i++){
        int k = elements[rand()%elements.size()];
        cout<<"\nEliminar "<<k<<"\n";
        btree->remove(k);
        btree->display_pretty();
    }

    return 0;
}