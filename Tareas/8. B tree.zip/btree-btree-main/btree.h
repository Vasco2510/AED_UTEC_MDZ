#ifndef BTree_H
#define BTree_H
#include <iostream>

#include "node.h"

using namespace std;

template <typename TK>
class BTree {
   private:
    Node<TK>* root;
    int M;  // grado u orden del arbol
    int n;  // total de elementos en el arbol

   public:
    BTree(int _M) : root(nullptr), M(_M) {}
    bool search(TK key);                 // indica si se encuentra o no un elemento
    void insert(TK key);                 // inserta un elemento
    void remove(TK key);                 // elimina un elemento
    int height();                        // altura del arbol. Considerar altura 0 para arbol vacio
    string toString(const string& sep);  // recorrido inorder
    TK minKey();                         // minimo valor de la llave en el arbol
    TK maxKey();                         // maximo valor de la llave en el arbol
    void clear();                        // eliminar todos lo elementos del arbol
    int size();                          // retorna el total de elementos insertados
    ~BTree();                            // liberar memoria

   private:  // Private functions to allow recursion
    bool search(Node<TK>* node, TK key);
    void insert(Node<TK>* node, TK key);
    void remove(Node<TK>* node, TK key);
    int height(Node<TK>* node);
    string toString(Node<TK>* node, const string& sep);
    TK minKey(Node<TK>* node);
    TK maxKey(Node<TK>* node);
    void clear(Node<TK>* node);
    int size(Node<TK>* node);
};

// -------------------------- Public Functions -----------------------------------
template <typename TK>
BTree<TK>::~BTree() {
    if (this->root != nullptr) {
        this->root->killSelf();
    }
}

template <typename TK>
bool BTree<TK>::search(TK key) {
    return (this->root == nullptr) ? false : search(this->root, key);
}

template <typename TK>
void BTree<TK>::insert(TK key) {
    insert(this->root, key);
}

template <typename TK>
void BTree<TK>::remove(TK key) {
    remove(this->root, key);
}

template <typename TK>
int BTree<TK>::height() {
    return height(this->root);
}

template <typename TK>
string BTree<TK>::toString(const string& sep) {
    return toString(this->root, sep);
}

template <typename TK>
TK BTree<TK>::minKey() {
    return minKey(this->root);
}

template <typename TK>
TK BTree<TK>::maxKey() {
    return maxKey(this->root);
}

template <typename TK>
void BTree<TK>::clear() {
    return clear(this->root);
}

template <typename TK>
int BTree<TK>::size() {
    return size(this->root);
}

// -------------------------- Private Functions -----------------------------------
template <typename TK>
bool BTree<TK>::search(Node<TK>* node, TK key) {
    int i = 0;
    for (; i < node->count && key >= node->keys[i]; i++) {
        if (key == node->keys[i]) {
            return true;
        }
    }

    if (node->leaf) {
        return false;
    } else {
        return search(node->children[i], key);
    }
}

template <typename TK>
void BTree<TK>::insert(Node<TK>* node, TK key) {
    // TODO
}

template <typename TK>
void BTree<TK>::remove(Node<TK>* node, TK key) {
    // TODO
}

template <typename TK>
int BTree<TK>::height(Node<TK>* node) {
    // TODO
    return 0;
}

template <typename TK>
string BTree<TK>::toString(Node<TK>* node, const string& sep) {
    // TODO
    return 0;
}

template <typename TK>
TK BTree<TK>::minKey(Node<TK>* node) {
    return 0;
}

template <typename TK>
TK BTree<TK>::maxKey(Node<TK>* node) {
    // TODO
    return 0;
}

template <typename TK>
void BTree<TK>::clear(Node<TK>* node) {
    if (node != nullptr) {
        for (int i = 0; i < node->count; i++) {
            if (!node->leaf) {
                clear(node->children[i]);
                node->children[i] = nullptr;
            }
            node->keys = nullptr;
        }
        if (!node->leaf) {
            clear(node->children[node->count]);
            node->children[node->count] = nullptr;
        }
        node->children = nullptr;
        node->keys = nullptr;
    }
}

template <typename TK>
int BTree<TK>::size(Node<TK>* node) {
    // TODO
    return 0;
}

#endif
