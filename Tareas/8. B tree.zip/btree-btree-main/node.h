#ifndef NODE_H
#define NODE_H

using namespace std;

template <typename TK>
struct Node {
    TK* keys;         // array de keys
    Node** children;  // array de punteros a hijos
    int count;        // cantidad de keys
    bool leaf;        // indicador de nodo hoja

    Node() : keys(nullptr), children(nullptr), count(0) {}
    
    Node(int M) {
        keys = new TK[M - 1];
        children = new Node<TK>*[M];
        count = 0;
        leaf = true;
    }

    void killSelf() {
        // TODO
    }
};

#endif