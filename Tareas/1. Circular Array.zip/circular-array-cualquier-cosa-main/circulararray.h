#include <iostream>
#include <string>
using namespace std;

template <class T> class CircularArray {
private:
  T *array;
  int capacity;
  int len=0;
  int back = -1;
  int front = -1;
  int next(int);
  int prev(int);

public:
  CircularArray();
  CircularArray(int _capacity);
  virtual ~CircularArray();

  void resize() {
    T *temp = new int[2 * capacity];
    for (int i = 0; i < capacity; i++) {
      temp[i] = array[front];
      front = next(front); // esta trabajando con el tamaño del
    }
    front = 0;
    delete[] array;
    capacity *= 2;
    back = capacity / 2 - 1;
    array = temp;
  }

  void push_front(T data) {
    if (is_full()) {
      resize();
    } else if (is_empty()) {
      front = back = 0;
    }
    front = prev(front);
    array[front] = data;
    len++;
  }

  void push_back(T data) {
    if (is_full()) {
      resize();
    } else if (is_empty()) {
      front = 0;
    }
    back = next(back);
    array[back] = data;
    len++;
  }

    void insert(T data, int pos){
      pos--;
      if (is_full()) {
          resize();
      }else if(is_empty()){
          front = 0;
          array[front] = data;
          back = 0;
          len++;
          return;
      }
      if(pos > len){
          back = next(back);
          array[back] = data;
          len++;
          return;
      }
      int temp_back = back;
      while (back != prev(front + pos)) {
          swap(array[back], array[next(back)]);
          back = prev(back);
      }
      back = next(temp_back);
      len++;
      int temp = (front + pos) % len;
      array[temp] = data;
    }

  T pop_front() {
    if (is_empty()) {
      throw "No puedes eliminar";
    }
    len--;
    front = next(front);
    if(!len) {
      back = -1;
      front = -1;
    }
    return array[prev(front)];
  }

  T pop_back() {
    len--;
    if (is_empty()) {
      throw "No puedes eliminar";
    }
    back = prev(back);
    if(!len) {
      back = front = -1;
    }
    return array[next(back)];
  }

  bool is_full() {
    if(len == capacity) return true;
    return false;

  }

  bool is_empty() {
    if(len) return false;
    return true;
  }


  T &operator[](int index){
		return array[(this->front + index) % this->capacity];
  }

  int size();   // implemented
  void clear(); // implemented
  void sort(); // implemented
  bool is_sorted(); // implemented
  void reverse(); // implemented
  string to_string(string sep = " "); // implemented
  void display();                     // implemented
  int getFront(); // implemented
  int getBack(); // implemented
  int getCap(); // implemented
};

template <class T> CircularArray<T>::CircularArray() { CircularArray(0); }

template <class T> CircularArray<T>::CircularArray(int _capacity) {
  this->array = new T[_capacity];
  this->capacity = _capacity;
  this->front = this->back = -1;
}

template <class T> 
CircularArray<T>::~CircularArray() { 
	delete[] array; 
}

template <class T> int CircularArray<T>::prev(int index) {
  return (index == 0) ? capacity - 1 : index - 1;
}

template <class T> int CircularArray<T>::next(int index) {
  return (index + 1) % capacity;
}

template <class T>
string CircularArray<T>::to_string(string sep)
{
    string result = ""; 
    for (int i = 0; i < size(); i++)
        result += std::to_string((*this)[i]) + sep;
    return result;    
}


template <class T>
void CircularArray<T>::display() {
    if(is_empty()) return;
  int temp = front;
  while (front != back) {
    cout << array[front] << ' ';
    front = next(front);
  }
  cout << array[front] << '\n';
  front = temp;
}

template <class T> bool CircularArray<T>::is_sorted() {
  int * temp = new int(front);
  while (*temp != back) {
    if (array[*temp] > array[next(*temp)]) return false;
    *temp = next(*temp);
  }
  return true;
}

template <class T>
void CircularArray<T>::sort(){
	for(int i = front; i != back - 1; i = next(i)){
		int min_idx = i;
		for (int j = next(i); j != next(back); j=next(j))
			if (array[j] < array[min_idx])
				min_idx = j;
        T temp = array[min_idx];
        array[min_idx]=array[i];
        array[i]= temp;
      }
  }

template <class T>
void CircularArray<T>::reverse(){
  int * temp1=new int(front), * temp2=new int(back),* c=new int(len/2);
  while((*c)--){
    swap(array[back],array[front]);
    front = next(front);
    back = prev(back);
  }
  front = *temp1;
  back = *temp2;
  delete temp1;
  delete temp2;
  delete c;
}

template <class T>
int CircularArray<T>::size() { return len; }

template <class T>
void CircularArray<T>::clear() {
  delete []array;
  back = -1;
  front = -1;
  len = 0;
  new T[capacity];
}

template <class T> int CircularArray<T>::getFront() { return front; }

template <class T> int CircularArray<T>::getBack() { return back; }

template <class T> int CircularArray<T>::getCap() { return capacity; }