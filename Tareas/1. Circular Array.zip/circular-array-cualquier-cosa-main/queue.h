#include "circulararray.h"

template <typename T>
class QueueArray : public CircularArray<T> { 
    public:
        void enqueue(T data){
          this->push_back(data);
          }
        T dequeue(){
            T temp=this->pop_front();
            return temp;
        }
};