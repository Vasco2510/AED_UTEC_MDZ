#ifndef FORWARD_H
#define FORWARD_H
#include <iostream>
#include "list.h"

// TODO: Implement all methods
template <typename T>
class ForwardList : public List<T> {
private:
  Node<T>* head;
  int nodes;

public:
  ForwardList() : List<T>() {
    head = nullptr;
    nodes = 0;
  }

  ~ForwardList(){
    // TODO
      while(head != nullptr){
          Node<T> * temp = head;
          head = head ->next;
          delete temp;
      }
      delete head;
      nodes = 0;
  }

  T front(){
      try{
          if(is_empty()) throw(nodes);
          return head->data;
      }
      catch(int nodes){
          std::cout << "No puedes obtener el front de una lista de "<<nodes << " elementos\n";
          return T{};
      }

  }

  T back(){
      try{
          if(is_empty()) throw(nodes);
          Node<T> * temp = head;
          while(temp->next!=nullptr){
              temp= temp->next;
          }
          return temp->data;
      }
      catch(int nodes){
          std::cout << "No puedes obtener el back de una lista de "<<nodes << " elementos\n";
          return T{};
      }
  }
  void push_front(T data){
    auto * temp = new Node<T>(data);
    temp->next = head;
    head = temp;
    nodes++;
  }


  void push_back(T data){
      if(is_empty()){
          push_front(data);
      return;
    }
        auto * nodo = new Node<T>(data);
    Node<T> * temp = head;
    while(temp->next!=nullptr){
      temp = temp->next;
    }
    temp->next = nodo;
    nodes++;
  }

  T pop_front(){
    try{
        if(is_empty()) throw(nodes);
        nodes--;
        Node<T> * temp = head;
        head = head->next;
        T data = temp->data;
        delete temp;
        return data;
    }
    catch(int nodes){
        std::cout << "No puedes eliminar elementos en una lista de "<<nodes << " elementos\n";
        return T{};
    }
  }
  T pop_back(){
      try {
          if(is_empty()) throw(nodes);
          else if(nodes == 1){
              nodes--;
              T data = head->data;
              delete head;
              head = nullptr;
              return data;
          }
          nodes--;
          Node<T> * temp = head;
          while(temp->next->next!= nullptr){
              temp = temp->next;
          }
          T data = temp->next->data;
          Node<T>* temp1 = temp->next;
          delete temp1;
          temp->next = nullptr;

          return data;
      }
      catch(int nodes){
          std::cout << "No puedes eliminar elementos en una lista de "<<nodes << " elementos\n";
          return T{};
      }
  }

  T insert(T data, int pos){
      if(pos>=nodes){
          push_back(data);
          return data;
      }
      if(pos <=0){
          push_front(data);
          return data;
      }
      pos--;
      nodes++;
      auto * nodo = new Node<T>(data);
      Node<T> * temp = head;
      while(pos--){
          temp = temp -> next;
      }
      nodo->next = temp->next;
      temp->next = nodo;
      return data;
  }

  bool remove(int pos){
      if(pos>=nodes || pos<0) return false;
      nodes--;
      if(!pos){
          pop_front();
          return true;
      }
      pos--;
      Node<T> * temp = head;
      while(pos--){
          temp = temp -> next;
      }
      Node<T> * to_eliminate = temp->next;
      temp->next = temp->next->next;
      delete to_eliminate;
      return true;
  }

  T& operator[](int pos){
      Node<T> * temp = head;
      while(pos--){
          temp = temp->next;
      }
      return temp->data;
  }

  bool is_empty(){
      return !nodes;
  }

  int size(){
      return nodes;
  }

  void clear(){
      //el head queda vivo apuntando a nullptr;
      while(head != nullptr){
          Node<T> * temp = head;
          head = head ->next;
          delete temp;
      }
      nodes = 0;
  }

  Node<T> * &  merge(Node<T> * &l1,Node<T> * &l2){
      auto * sorted_temp = new Node<T> (0);
      Node<T> * current_node = sorted_temp;
      while(l1 != nullptr && l2 != nullptr){
          if(l1->data < l2->data){
              current_node->next = l1;
              l1 = l1->next;
          }else{
              current_node->next = l2;
              l2 = l2->next;
          }
          current_node = current_node->next;
      }
      if(l1!= nullptr){
          current_node->next = l1;
          l1 = l1->next;
      }
      if(l2!= nullptr){
          current_node->next = l2;
          l2 = l2->next;
      }
      return sorted_temp->next;
  }

  Node<T> * & merge_sort(Node<T> * &temp_head){

        if(temp_head == nullptr || temp_head->next == nullptr) {
            return temp_head;
        }
        Node<T> * temp = temp_head;
        Node<T> * slow = temp_head;
        Node<T> * fast = temp_head;

        while(fast!= nullptr && fast->next != nullptr){
            temp = slow;
            slow = slow->next;
            fast = fast->next->next;
        }
        temp->next = nullptr;
        Node<T> * left_side = merge_sort(temp_head);
        Node<T> * right_side = merge_sort(slow);
        return merge(left_side,right_side);
  }

  void sort(){
      head = merge_sort(head);
  }

  bool is_sorted(){
      if (is_empty()) return false;
      Node<T> * first = head;
      Node<T> * second = first->next;
      while(second!=nullptr){
          if(first->data > second->data){
              return false;
          }
          first = first->next;
          second = second->next;
      }
      return true;
  }

  void reverse(){
      if (nodes<2) return;
      Node<T> * first = head;
      Node<T> * second = head->next;
      Node<T> * third = head->next->next;
      first->next = nullptr;
      while(third!=nullptr){
          second->next = first;
          first = second;
          second = third;
          third= third->next;
      }
      second->next = first;
      head = second;
  }

  std::string name(){
      return "ForwardList";
  }

};

#endif
