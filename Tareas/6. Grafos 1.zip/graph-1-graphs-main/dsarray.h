#ifndef DSARRAY_H
#define DSARRAY_H

#include<vector>
#include<iostream>
template <typename T>
class DisjoinSetArray
{
private:
    // define the structures
    int * parent;
    int * rango;
    int * data;
    int tama;
public:
    // implement all functions
    DisjoinSetArray(std::vector<T> data){
        parent = new int[data.size()];
        rango = new int[data.size()];
        tama = data.size();
        this->data = new int[data.size()];
        for(int i = 0; i < tama;i++){
            MakeSet(i);
            this->data[i] = data[i];
        }
    }

    ~DisjoinSetArray(){
        delete [] parent;
        delete [] rango;
        delete [] data;
    }

    /*
    * x, y are indexes
    */
    //MakseSet the element with index x
    void MakeSet(int x){
        parent[x] = x;
        rango[x] = 0;
    }
    //Find the root of x (with optimization by rank)
    int Find(int x){
        if(parent[x] != x) return Find(parent[x]);
        return parent[x];
    }
    //Find the root of x (with optimization path compression)
    int FindPathCompression(int x){
        if(parent[x] != x) {
            parent[x] = FindPathCompression(parent[x]);
            return parent[x];
        }
        return parent[x];
    }
    //Union two sets represented by x and y (apply rank)
    void Union(int x, int y) {
        if(FindPathCompression(x) == FindPathCompression(y)) {
            return;
        }
        if(rango[FindPathCompression(x)] < rango[FindPathCompression(y)]){
            parent[FindPathCompression(x)] = FindPathCompression(y);
        }else if(rango[FindPathCompression(x)] > rango[FindPathCompression(y)]){
            parent[FindPathCompression(y)] = FindPathCompression(x);
        }else if(rango[FindPathCompression(x)] == rango[FindPathCompression(y)]){
            parent[FindPathCompression(x)] = FindPathCompression(y);
            rango[FindPathCompression(y)]++;
        }
    }

    //check whether there is a path between x and y
    bool isConnected(int x, int y){
        return parent[x] == parent[y];
    }
    //total number of elements
    int size(){
        return tama;
    }
    //number of sets
    int sets() { // o(n^2)
        int cnt = 0;
        for(int i = 0; i < tama;i++){
            cnt+=!(FindPathCompression(i) - i);
        }
        return cnt;
    }
    //total number of elements that belong to the set of x
    int size(int x){
        int cnt = 0;
        int cmp = parent[x];
        for(int i = 0; i < tama;i++){
            cnt+=!(FindPathCompression(i)-cmp);
        }
        return cnt;
    }//Complejidad?
    //return all elements that belong to the set of x
    std::vector<T> getElementsSet(int x){
        std::vector<T> ans;
        int cmp = parent[FindPathCompression(x)];
        for(int i = 0; i < tama;i++){
            if(cmp == parent[FindPathCompression(i)]) ans.push_back(data[i]);
        }
        return ans;
    }//Complejidad?
    void display(){
        for(int i = 0; i < tama;i++){
            std::cout << parent[i] << ' ';
        }
        std::cout << '\n';
    }
};

#endif
