#include <list>
#include <vector>
#include<queue>
#include <unordered_map>
#include<iostream>
#include<stack>
#include<algorithm>
#include "dsarray.h"
using namespace std;

template<typename TV, typename TE>
struct Edge;

template<typename TV, typename TE>
struct Vertex;

template<typename TV, typename TE>
class Graph;

//////////////////////////////////////////////////////

template<typename TV, typename TE>
struct Edge {
    Vertex<TV, TE>* vertexes[2];
    TE weight;
};

template<typename TV, typename TE>
struct Vertex {
    TV data;
    int id;
    std::list<Edge<TV, TE>*> edges;
    explicit Vertex(TV data,int id){
        this->data = data;
        this->id = id;
    }
};

template<typename TV, typename TE>
class Graph{
private:
    std::unordered_map<int, Vertex<TV, TE>*>  vertexes;

public:
    void insertVertex(int id, TV vertex){
        auto * vertice = new Vertex<TV,TE>(vertex,id);
        vertexes[id] = vertice;
    }// Creates a new vertex in the graph with some data and an ID

    void createEdge(int id1, int id2, TE w){
        auto * new_edge1 = new Edge<TV,TE>();
        new_edge1->vertexes[0] = vertexes[id1];
        new_edge1->vertexes[1] = vertexes[id2];
        new_edge1->weight = w;
        auto * new_edge2 = new Edge<TV,TE>();
        new_edge2->vertexes[1] = vertexes[id1];
        new_edge2->vertexes[0] = vertexes[id2];
        new_edge2->weight = w;
        vertexes[id1]->edges.push_front(new_edge1);
        vertexes[id2]->edges.push_front(new_edge2);
    } // Creates a new edge in the graph with some data

    void displayVertex(int id){
        cout << vertexes[id]->data <<":\t";
        for(auto itr = (vertexes[id]->edges).begin(); itr!= (vertexes[id]->edges).end();itr++){
            cout << (*itr)->vertexes[1]->data << '(' << (*itr)->weight<<')' << '\t';
        }
        cout << '\n';
    }

    void display(){
        for(auto itr:vertexes){
            displayVertex(itr.first);
        }
    }
    bool deleteEdge(int startId, int endId){
        bool valid = false;
        vertexes[startId]->edges.template remove_if([&valid,endId](auto a){
            if(endId == a->vertexes[1]->id){
                valid = true;
            }
            return endId == a->vertexes[1]->id;
        });
        vertexes[endId]->edges.template remove_if([startId](auto a){
            return startId == a->vertexes[1]->id;
        });
        return valid; //el remove_if controla los casos en los que no hay una relacion
    }
    bool deleteVertex(int id){
        auto iter = vertexes.find(id);
        if (iter == vertexes.end()){
            return false;
        }else if(vertexes[id]->edges.size()){
            auto temp = vertexes[id]->edges.begin();
            for(auto itr = next(vertexes[id]->edges.begin()); itr != vertexes[id]->edges.end();itr++){
                deleteEdge(id,(*temp)->vertexes[1]->id);
                temp = itr;
            }
            deleteEdge(id,(*temp)->vertexes[1]->id);
            for(auto itr : vertexes){
                itr.second->edges.template remove_if([id](auto a){
                    return id == a->vertexes[1]->id;
                });
            }
            vertexes.erase(id);
            return true;
        }
        vertexes.erase(id);
        return true;
    }

    TE &operator()(int startId, int endId){
        //ver el caso donde no tenga conexiones.
        for(auto itr = vertexes[startId]->edges.begin();itr!=vertexes[startId]->edges.end();itr++){
            if((*itr)->vertexes[1]->id == endId){
                return (*itr)->weight;
            }
        }
        throw("No se encontro la arista");
    }
    [[nodiscard]] float density() const{
        float d = 0;
        for(auto i : vertexes){
            d+=i.second->edges.size();
        }
        return d*1.0/(vertexes.size()*(vertexes.size()-1));
    }
    bool empty(){
        return vertexes.empty();
    }
    void clear(){
        auto temp = vertexes.begin();
        for(auto itr = next(vertexes.begin()); itr!=vertexes.end();itr++){
            deleteVertex((*temp).second->id);
            temp = itr;
        }
        deleteVertex((*temp).second->id);
    }
    [[nodiscard]] bool isDense(float threshold = 0.5) const{
        return density()>threshold;
    }
    Graph<char, float> execKruskal(){
        if (vertexes.size() == 0)
            throw("No se puede generar un arbol");
        vector<Edge<TV,TE>*> almacenamiento;
        vector<int> vertices;
        for(auto i : vertexes){
            vertices.push_back(i.first);
            for(auto j=i.second->edges.begin();j != i.second->edges.end();j++){
                almacenamiento.push_back(*j);
            }
        }
        sort(almacenamiento.begin(),almacenamiento.end(),[](auto a, auto b){
            return (*a).weight < (*b).weight;
        });
        auto * ds = new DisjoinSetArray<int>(vertices);

        Graph<char,float> mst;
        for(auto i : vertexes){
            mst.insertVertex(i.first,i.second->data);
        }
        for(auto i : almacenamiento){
            //falta cambiar por un unordered_map
            if(ds->Find(i->vertexes[0]->id-1) != ds->Find(i->vertexes[1]->id-1)){
                mst.createEdge(i->vertexes[0]->id,i->vertexes[1]->id, i->weight);
                ds->Union(i->vertexes[0]->id-1, i->vertexes[1]->id-1);
            }
        }
        return mst;
    }
    template<typename cola>
    Edge<TV,TE> * add_edges(cola & q, unordered_map<int,bool> & visited, int index){
        for(auto itr = vertexes[index]->edges.begin();itr!=vertexes[index]->edges.end();itr++){
            q.push(*itr);
        }
        while(!q.empty() && visited[q.top()->vertexes[1]->id]){
            q.pop();
        }
        if(visited[q.top()->vertexes[1]->id]){
            for(auto itr:vertexes){
                if(!visited[itr.first]){
                    while(!q.empty()){
                        q.pop();
                    }
                    visited[itr.first] = true;
                    return *itr.second->edges.begin();
                }
            }
        }
        visited[q.top()->vertexes[1]->id] = true;
        return q.top();
    }
    Graph<char, float> execPrim(){
        if (vertexes.size() == 0)
        throw("No se puede generar un arbol");
        Graph<char,float> mst;
        auto cmp = [](Edge<TV,TE>* a, Edge<TV,TE>* b){ return a->weight < b->weight;};
        priority_queue<Edge<TV,TE>*,vector<Edge<TV,TE>*>,decltype(cmp)> q(cmp);
        unordered_map<int,bool> visited;
        mst.insertVertex(vertexes.begin()->second->id,vertexes.begin()->second->data);
        int vertice_i = vertexes.begin()->second->id;
        visited[vertexes.begin()->second->id] = true;
        while(mst.vertexes.size() < vertexes.size()){
            auto temp_vertice_i = add_edges(q,visited,vertice_i);
            mst.insertVertex(temp_vertice_i->vertexes[1]->id,vertexes[temp_vertice_i->vertexes[1]->id]->data);
            mst.createEdge(vertice_i,temp_vertice_i->vertexes[1]->id,temp_vertice_i->weight);
            vertice_i = temp_vertice_i->vertexes[1]->id;
        }
        return mst;
    }

    Graph<char, float> execDFS(){
        if (vertexes.size() == 0)
            throw("No se puede generar un arbol");
        stack<Vertex<TV,TE>*> s;
        Graph<char,float> ans;
        Vertex<TV,TE>* root = (vertexes.begin())->second;
        unordered_map<int,bool> seen;
        seen[root->id] = true;
        s.push(root);
        while(!s.empty()){
            auto temp = s.top();
            s.pop();
            for(auto itr =temp->edges.begin();itr!=temp->edges.end();itr++){
                if(!seen[(*itr)->vertexes[1]->id]) {
                    s.push((*itr)->vertexes[1]);
                    seen[(*itr)->vertexes[1]->id] = true;
                }
            }
            ans.insertVertex(temp->id,temp->data);
            if(!s.empty()) {
                ans.insertVertex(s.top()->id,s.top()->data);
                ans.createEdge(temp->id,s.top()->id,this->operator()(temp->id,s.top()->id));
            }
        }
        return ans;
    }
    Graph<char, float> execBFS(){
        if (vertexes.size() == 0)
            throw("No se puede generar un arbol");
        queue<Vertex<TV,TE>*> q;
        Graph<char,float> ans;
        Vertex<TV,TE>* root = (vertexes.begin())->second;
        unordered_map<int,bool> seen;
        seen[root->id] = true;
        q.push(root);
        while(!q.empty()){
            auto temp = q.front();
            q.pop();
            ans.insertVertex(temp->id,temp->data);
            for(auto itr =temp->edges.begin();itr!=temp->edges.end();itr++) {
                if (!seen[(*itr)->vertexes[1]->id]) {
                    q.push((*itr)->vertexes[1]);
                    seen[(*itr)->vertexes[1]->id] = true;
                    ans.insertVertex((*itr)->vertexes[1]->id, (*itr)->vertexes[1]->data);
                    ans.createEdge(temp->id,(*itr)->vertexes[1]->id,this->operator()(temp->id,(*itr)->vertexes[1]->id));
                }
            }
        }
        return ans;
    }
    bool isConnected(){
        if (vertexes.size() == 0)
            throw("No se puede generar un arbol");
        auto temp = this;
        auto g = temp->execDFS();
        return temp->vertexes.size() ==vertexes.size();
    } // Detect if the graph is connected
}
