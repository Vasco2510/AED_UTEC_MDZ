#include <cmath>
#include <iostream>
#include <string>

#include "double.h" //Agregado al repositorio
using namespace std;

template<typename T>
class Stack: public DoubleList<T>{
public:
    Stack(): DoubleList<T>(){};
    void push(T data){
        this->push_back(data);
    }
    bool empty(){
        return this->is_empty();
    }
    T pop(){
        return this->pop_back();
    }
    T top(){
        return this->back();
    }
};

template<typename T>
class Queue: public DoubleList<T>{
public:
    Queue(): DoubleList<T>(){};
    void push(T data){
        this->push_back(data);
    }
    bool empty(){
        return this->is_empty();
    }
    T pop(){
        return this->pop_front();
    }
    T front1(){
        return this->front();
    }
};


struct Result {
    double result;
    bool error;
    Result(double r, bool e){
        result = r;
        error = e;
    }
};

void double_trans(string &a, Stack<double> &result) {
    if (!a.empty()) {
        result.push(stod(a));
    }
    a = "";
}

void get_result(Queue<char> &r, Result &ans) {
    Stack<double> result;
    string a = "";

    while (!r.empty()) {
        if (r.front1() == '|') {
            double_trans(a, result);
        } else if (r.front1() == '*' || r.front1() == '/' || r.front1() == '^' ||
                   r.front1() == '-' || r.front1() == '+') {
            double_trans(a, result);
            double temp1, temp2;
            if (!result.empty())
                temp1 = result.top();
            else {
                ans.error = true;
                return;
            }
            result.pop();
            if (!result.empty())
                temp2 = result.top();
            else {
                ans.error = true;
                return;
            }
            result.pop();
            if (r.front1() == '*')
                result.push(temp2 * temp1);
            else if (r.front1() == '+')
                result.push(temp2 + temp1);
            else if (r.front1() == '-')
                result.push(temp2 - temp1);
            else if (r.front1() == '/')
                result.push(temp2 / temp1);
            else if (r.front1() == '^')
                result.push(pow(temp2, temp1));
        } else {
            a += r.front1();
        }
        r.pop();

    }
    ans.result = result.top();
}

int get_priority(const char &a) {
    int priority = 0;
    if (a == 41 || a == 93 || a == 125)
        priority = 4;
    else if (a == 94)
        priority = 3;
    else if (a == 42 || a == 47)
        priority = 2;
    else if (a == 43 || a == 45)
        priority = 1;
    return priority;
}

void comparador(Stack<char>& pila,const int & f_priority, const char  i, Queue<char> & result){
    if (!pila.empty() && get_priority(pila.top()) == f_priority) {
        result.push(pila.top());
        pila.pop();
    } else if (!pila.empty() && get_priority(pila.top()) > f_priority) {
        while (!pila.empty() && get_priority(pila.top())) {
            result.push(pila.top());
            pila.pop();
        }
    }
    pila.push(i);
}


Result evaluate(const string & s) {
    Result ans = Result(-1,false);
    Stack<char> pila;
    Queue<char> result;
    bool seen = true;
    int who_past = -1;
    int who_current = -1;
    for (char  i : s) {
        if(who_past != -1) who_current = who_past;
        if (i == ' '){
            if(who_past == 2) {
                who_past = 0;
            }
            continue;
        }
        int f_priority = get_priority(i);
        if((who_current == 4 && (i == '(' || i == '[' || i == '{' || !f_priority || !who_past)) || ((!who_current || who_current == 2) && (i == '(' || i == '[' || i == '{'))){
            if(!who_current || who_current == 2) seen = false;
            comparador(pila,2,'*',result);
        }

        if (i == 40 || i == 91 || i == 123) {
            pila.push(i);
            who_past = 1;
            continue;
        }

        if((who_current == 3 && f_priority) || (who_current == 1 &&  f_priority && f_priority !=4 ) || (!who_current && !f_priority)) {
            ans.error = true;
            return ans;
        }

        if (!f_priority) {
            who_past = 2;
            if (!seen) {
                result.push('|');
                seen = true;
            }
            result.push(i);
        }
        else if (f_priority == 4) {
            who_past = 4;
            if (pila.empty()) {
                ans.error = true;
                return ans;
            }
            char compare = 'A';
            while (!pila.empty()) {
                compare = pila.top();
                pila.pop();
                if (!get_priority(compare)) {

                    if ((compare == 40 && i == 41) || (compare == 91 && i == 93) || (compare == 123 && i == 125)){
                        break;
                    }
                    else {
                        ans.error = true;
                        return ans;
                    }
                }
                result.push(compare);
            }
            if(get_priority(compare)){

                ans.error = true;
                return ans;
            }
        }
        else {
            if(who_past == -1) {
                ans.error = true;
                return ans;
            }
            who_past = 3;
            seen = false;
            comparador(pila,f_priority,i,result);
        }

    }
    while (!pila.empty()) {
        if (pila.top() == '(' || pila.top() == '{' || pila.top() == '[') {
            ans.error = true;
            return ans;
        }
        result.push(pila.top());
        pila.pop();
    }
    if(who_past == 3){
        ans.error = true;
        return ans;
    }
    get_result(result, ans);
    return ans;
}
